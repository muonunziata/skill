"""Lehigh News Hub agents: researcher -> writer -> auditor -> social designer -> WordPress hub."""

__version__ = "1.6.1"
