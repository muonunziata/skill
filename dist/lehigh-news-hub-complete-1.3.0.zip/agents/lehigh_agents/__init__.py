"""Lehigh News Hub agents: researcher -> writer -> auditor -> social designer -> WordPress hub."""

__version__ = "1.3.0"
